# airport_simulation
This simulates the overall state transition diagram.
![overall](airport.png)
